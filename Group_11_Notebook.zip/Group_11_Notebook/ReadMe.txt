Não colocamos o ficheiro x_test_agreement (teste já com Agreement reached previsto) por uma questão de falta de espaço.
Este ficheiro vai encontrar-se também no GitHub na sua própria pasta.

